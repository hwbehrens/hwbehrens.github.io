python3 viz_notifier.py 192.168.0.250 3000 MODEL
