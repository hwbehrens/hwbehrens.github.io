Put this folder onto the desktop of the Kepler machine, and call the 'viz_notifier' once when Kepler first executes the simulation cluster.

Output Manager will handle the rest.